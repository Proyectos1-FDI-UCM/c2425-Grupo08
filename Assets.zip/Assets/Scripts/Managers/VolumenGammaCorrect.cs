//---------------------------------------------------------
// Breve descripción del contenido del archivo: Controla el Gamma
// Responsable de la creación de este archivo: Andrés Díaz Guerrero Soto
// Nombre del juego
// Proyectos 1 - Curso 2024-25
//---------------------------------------------------------

using UnityEngine;
// Añadir aquí el resto de directivas using
using UnityEngine.UI;
using UnityEngine.Experimental.Rendering.Universal;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.InputSystem;

/// <summary>
/// Antes de cada class, descripción de qué es y para qué sirve,
/// usando todas las líneas que sean necesarias.
/// </summary>
public class VolumenGammaCorrect : MonoBehaviour
{
    // ---- ATRIBUTOS DEL INSPECTOR ----
    #region Atributos del Inspector (serialized fields)
    // Documentar cada atributo que aparece aquí.
    // El convenio de nombres de Unity recomienda que los atributos
    // públicos y de inspector se nombren en formato PascalCase
    // (palabras con primera letra mayúscula, incluida la primera letra)
    // Ejemplo: MaxHealthPoints

    [Header("Referencias")]
    [SerializeField] private Light2D globalLight = null;
    [SerializeField] private Volume globalVolume = null;
    [Header("Sliders UI")]
    [SerializeField] private Slider intensitySlider = null;
    [SerializeField] private Slider exposureSlider = null;
    [SerializeField] private Slider contrastSlider = null;
    [Header("Buttons UI")]
    [SerializeField] private Button mainMenuButton = null;
    [SerializeField] private Button continueButton = null;


    #endregion

    // ---- ATRIBUTOS PRIVADOS ----
    #region Atributos Privados (private fields)
    // Documentar cada atributo que aparece aquí.
    // El convenio de nombres de Unity recomienda que los atributos
    // privados se nombren en formato _camelCase (comienza con _, 
    // primera palabra en minúsculas y el resto con la 
    // primera letra en mayúsculas)
    // Ejemplo: _maxHealthPoints

    private ColorAdjustments colorAdjust;

    // Claves para PlayerPrefs
    private const string KeyIntensity = "Gamma_Intensity";
    private const string KeyExposure = "Gamma_Exposure";
    private const string KeyContrast = "Gamma_Contrast";

    #endregion

    // ---- MÉTODOS DE MONOBEHAVIOUR ----
    #region Métodos de MonoBehaviour

    // Por defecto están los típicos (Update y Start) pero:
    // - Hay que añadir todos los que sean necesarios
    // - Hay que borrar los que no se usen 

    /// <summary>
    /// Start is called on the frame when a script is enabled just before 
    /// any of the Update methods are called the first time.
    /// </summary>
    
    private void OnEnable()
    {
        // Suscribir eventos de dispositivo
        InputSystem.onDeviceChange += OnDeviceChange;
    }
    private void OnDisable()
    {
        InputSystem.onDeviceChange -= OnDeviceChange;
    }

    void Start()
    {
        // Validaciones
        if (globalLight == null || globalVolume == null
            || intensitySlider == null || exposureSlider == null || contrastSlider == null
            || mainMenuButton == null || continueButton == null)
        {
            Debug.LogError("LightAndVolumeController: faltan referencias en el inspector.");
            enabled = false;
            return;
        }

        // Obtener override Color Adjustments
        if (!globalVolume.profile.TryGet<ColorAdjustments>(out colorAdjust))
        {
            Debug.LogError("LightAndVolumeController: el Volume Profile no contiene Color Adjustments.");
            enabled = false;
            return;
        }

        // Configurar rangos de sliders
        intensitySlider.minValue = 0f;
        intensitySlider.maxValue = 0.2f;
        exposureSlider.minValue = -5f;
        exposureSlider.maxValue = 5f;
        contrastSlider.minValue = -100f;
        contrastSlider.maxValue = 100f;

        // Cargar valores guardados o usar valores por defecto
        float savedIntensity = PlayerPrefs.GetFloat(KeyIntensity, globalLight.intensity);
        float savedExposure = PlayerPrefs.GetFloat(KeyExposure, colorAdjust.postExposure.value);
        float savedContrast = PlayerPrefs.GetFloat(KeyContrast, colorAdjust.contrast.value);

        // Inicializar valores actuales
        globalLight.intensity = savedIntensity;
        colorAdjust.postExposure.value = savedExposure;
        colorAdjust.contrast.value = savedContrast;

        intensitySlider.value = savedIntensity;
        exposureSlider.value = savedExposure;
        contrastSlider.value = savedContrast;

        // Suscribir callbacks
        intensitySlider.onValueChanged.AddListener(OnIntensityChanged);
        exposureSlider.onValueChanged.AddListener(OnExposureChanged);
        contrastSlider.onValueChanged.AddListener(OnContrastChanged);

        // Configurar navegación explícita de gamepad
        SetupNavigation();

        // Seleccionar primer elemento
        intensitySlider.Select();

        // Detectar mando
        if (IsGamepadConnected())
            Debug.Log("Gamepad detectado: UI listo para navegación de mando.");
    }


    /// <summary>
    /// Update is called every frame, if the MonoBehaviour is enabled.
    /// </summary>
    void Update()
    {
        
    }

    private void OnDeviceChange(InputDevice device, InputDeviceChange change)
    {
        if (device is Gamepad)
        {
            if (change == InputDeviceChange.Added)
                Debug.Log("Gamepad conectado dinámicamente.");
            else if (change == InputDeviceChange.Removed)
                Debug.Log("Gamepad desconectado dinámicamente.");

            // Refrescar navegación UI
            SetupNavigation();
        }
    }

    private bool ValidateReferences()
    {
        if (globalLight == null || globalVolume == null || intensitySlider == null || exposureSlider == null || contrastSlider == null || mainMenuButton == null || continueButton == null)
        {
            Debug.LogError("LightAndVolumeController: faltan referencias en inspector.");
            enabled = false;
            return false;
        }
        return true;
    }

    #endregion

    // ---- MÉTODOS PÚBLICOS ----
    #region Métodos públicos
    // Documentar cada método que aparece aquí con ///<summary>
    // El convenio de nombres de Unity recomienda que estos métodos
    // se nombren en formato PascalCase (palabras con primera letra
    // mayúscula, incluida la primera letra)
    // Ejemplo: GetPlayerController

    #endregion

    // ---- MÉTODOS PRIVADOS ----
    #region Métodos Privados
    // Documentar cada método que aparece aquí
    // El convenio de nombres de Unity recomienda que estos métodos
    // se nombren en formato PascalCase (palabras con primera letra
    // mayúscula, incluida la primera letra)

    private void SetupSliders()
    {
        intensitySlider.minValue = 0f; intensitySlider.maxValue = 0.2f;
        exposureSlider.minValue = -5f; exposureSlider.maxValue = 5f;
        contrastSlider.minValue = -100f; contrastSlider.maxValue = 100f;
    }
    private void LoadSavedValues()
    {
        float si = PlayerPrefs.GetFloat(KeyIntensity, globalLight.intensity);
        float se = PlayerPrefs.GetFloat(KeyExposure, colorAdjust.postExposure.value);
        float sc = PlayerPrefs.GetFloat(KeyContrast, colorAdjust.contrast.value);
        globalLight.intensity = si;
        colorAdjust.postExposure.value = se;
        colorAdjust.contrast.value = sc;
        intensitySlider.value = si;
        exposureSlider.value = se;
        contrastSlider.value = sc;
    }
    private void SubscribeUI()
    {
        intensitySlider.onValueChanged.AddListener(OnIntensityChanged);
        exposureSlider.onValueChanged.AddListener(OnExposureChanged);
        contrastSlider.onValueChanged.AddListener(OnContrastChanged);
    }
    /// <summary>
    /// Define navegación explícita para gamepad entre sliders y botones.
    /// </summary>
    private void SetupNavigation()
    {
        var exp = Navigation.Mode.Explicit;
        // Intensity
        var n0 = intensitySlider.navigation; n0.mode = exp;
        n0.selectOnDown = exposureSlider; n0.selectOnUp = continueButton;
        intensitySlider.navigation = n0;
        // Exposure
        var n1 = exposureSlider.navigation; n1.mode = exp;
        n1.selectOnDown = contrastSlider; n1.selectOnUp = intensitySlider;
        exposureSlider.navigation = n1;
        // Contrast
        var n2 = contrastSlider.navigation; n2.mode = exp;
        n2.selectOnDown = mainMenuButton; n2.selectOnUp = exposureSlider;
        contrastSlider.navigation = n2;
        // MainMenu
        var n3 = mainMenuButton.navigation; n3.mode = exp;
        n3.selectOnDown = continueButton; n3.selectOnUp = contrastSlider;
        mainMenuButton.navigation = n3;
        // Continue
        var n4 = continueButton.navigation; n4.mode = exp;
        n4.selectOnDown = intensitySlider; n4.selectOnUp = mainMenuButton;
        continueButton.navigation = n4;
    }
    private void OnIntensityChanged(float v)
    {
        globalLight.intensity = v;
        PlayerPrefs.SetFloat(KeyIntensity, v);
    }
    private void OnExposureChanged(float v)
    {
        colorAdjust.postExposure.value = v;
        PlayerPrefs.SetFloat(KeyExposure, v);
    }
    private void OnContrastChanged(float v)
    {
        colorAdjust.contrast.value = v;
        PlayerPrefs.SetFloat(KeyContrast, v);
    }
    /// <summary>
    /// Determina si hay al menos un gamepad activo.
    /// </summary>
    public bool IsGamepadConnected()
    {
        return Gamepad.all.Count > 0;
    }

    private void OnDestroy()
    {
        intensitySlider.onValueChanged.RemoveListener(OnIntensityChanged);
        exposureSlider.onValueChanged.RemoveListener(OnExposureChanged);
        contrastSlider.onValueChanged.RemoveListener(OnContrastChanged);
    }

    #endregion   

} // class VolumenGammaCorrect 
// namespace
